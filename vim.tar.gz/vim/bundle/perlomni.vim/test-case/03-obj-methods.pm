# smart object method completion



my $obj = new Jifty::Web;
$obj->caller

my $var = new Jifty;
$var->app_instance_id


my $cgi = new CGI;
print $cgi->

my $cgi2 = CGI->new;
$cgi2->

# complete class methods
Jifty::DBI::Record->__create
Jifty->
Moose->
Catalyst::Action->code
